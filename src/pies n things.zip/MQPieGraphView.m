//
//  MQPieGraphView.m
//  
//
//  Created by John Carlyle on 11/12/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "MQSlice.h"
#import "MQPieGraphView.h"

//#define MIN(x, y) (x < y) ? x : y;

@implementation MQPieGraphView


- (id)initWithFrame:(NSRect)frameRect
{
    self = [super initWithFrame:frameRect];
    
    if (self)   {
        drawLegend = NO;
        autosize = YES;
        size = 50;
        bg = [NSColor whiteColor];
        lineColor = [NSColor blackColor];
        textColor = [NSColor blackColor];
        slices = [[NSMutableArray alloc] initWithCapacity:2];
    }
    
    return self;
}

- (MQSlice *)getSliceForPoint:(NSPoint)p
{
    int j;
    for (j = 0 ; j < [slices count]; j++)  {
        NSBezierPath *path = [[slices objectAtIndex:j] getBezierPath];
        if ([path containsPoint:p])   {
            return [slices objectAtIndex:j];
        }
    }
    return nil;
}


- (void)drawRect:(NSRect)rect
{
    [bg set];
    [NSBezierPath fillRect:rect];
    
    int oldSize = size;
    if (autosize)   {
        size = MIN(rect.size.width/2 - padding, rect.size.height/2 - padding);
    }
    
    NSPoint centerPoint;
    centerPoint.x = rect.size.width/2;
    centerPoint.y = rect.size.height/2;
    
    int i;
    float angle = 0.0f;
    NSBezierPath *slicePath = [[NSBezierPath alloc] init];
    
    NSShadow *clearShadow = [[NSShadow alloc] init];
    [clearShadow setShadowColor:nil];
    NSShadow *shadow = [[NSShadow alloc] init];
    [shadow setShadowOffset:NSMakeSize(padding/2, -padding/2)];
    [shadow setShadowBlurRadius:0.0f];
    
    for ( i = 0 ; i < [slices count]; i++)  {
        NSBezierPath *sliceFill = [[NSBezierPath alloc] init];
        MQSlice *slice = [slices objectAtIndex:i];
        
        [sliceFill moveToPoint:centerPoint];
        [sliceFill appendBezierPathWithArcWithCenter:centerPoint radius:size startAngle:angle endAngle:angle + [slice getSlice]];
        [clearShadow set];
        [slicePath appendBezierPath:sliceFill];
        [[slices objectAtIndex:i] setBezierPath:sliceFill];
        
        angle += [slice getSlice];
        
        [[slice getColor] set];
        [shadow set];
        [sliceFill fill];
        [clearShadow set];
        if (drawLegend)   {
            [self drawLegend:slice i:i];
        }
    }
    [lineColor set];
    [slicePath stroke];
    size = oldSize;
}


- (void)drawLegend:(MQSlice *)slice i:(int)i
{
    NSPoint drawPoint;
    drawPoint.x = 17;
    drawPoint.y = (i * 15) + 15;
    
    [NSBezierPath fillRect:NSMakeRect(drawPoint.x - 7, drawPoint.y + 10, 10, 10)];
    
    NSTextStorage *storage = [[NSTextStorage alloc] initWithString:[slice getMessage]];
    [storage setForegroundColor:textColor];
    NSLayoutManager *lm = [[NSLayoutManager alloc] init];
    NSTextContainer *container = [[NSTextContainer alloc] init];
    
    [lm addTextContainer:container];
    [container release];
    [storage addLayoutManager:lm];
    [lm release];
    
    NSRange glyphRange = [lm glyphRangeForTextContainer:container];
    [self lockFocus];
    [lm drawGlyphsForGlyphRange:glyphRange atPoint:drawPoint];
    [self unlockFocus];
    
}

- (void)updateView
{
    int i;
    float total = 0.0f;
    for (i = 0 ; i < [slices count] ; i++)  {
        MQSlice *tempSlice = [[MQSlice alloc] init];
        tempSlice = [slices objectAtIndex:i];
        total += [tempSlice getSlice];
    }
    if (total < 360.0)    {
        NSLog(@"Not enough slices:%f. Needs 360 degrees", total);
        return;
    }
    if (total > 360.0)   {
        NSLog(@"Too many slices:%f. Needs 360 degrees", total);
        return;
    }
    
    [self setNeedsDisplay:YES];
}

- (BOOL)getDrawsLegend
{
    return drawLegend;
}

- (void)setDrawsLegend:(BOOL)s
{
    drawLegend = s;
}


- (BOOL)getAutosizes
{
    return autosize;
}

- (void)setAutosizes:(BOOL)s
{
    autosize = s;
}


- (void)setSize:(int)s
{
    size = s;
}

- (int)getSize
{
    return size;
}

- (void)setPadding:(float)pad
{
    padding = pad;
}

- (float)getPadding
{
    return padding;
}

- (void)addSlice:(MQSlice *)slice
{
    [slices addObject:slice];
}

- (void)removeSliceAtIndex:(int)index
{
    [slices removeObjectAtIndex:index];
}

- (void)clearSlices
{
    [slices removeAllObjects];
}


- (MQSlice *)getSliceAtIndex:(int)index
{
    return [slices objectAtIndex:index];
}

- (void)setLineColor:(NSColor *)newColor
{
    [lineColor release];
    lineColor = [newColor retain];
}

- (NSColor *)getLineColor
{
    return lineColor;
}

- (void)setTextColor:(NSColor *)newColor
{
    [textColor release];
    textColor = [newColor retain];
}

- (NSColor *)getTextColor
{
    return textColor;
}


- (void)setBackground:(NSColor *)newColor
{
    [bg release];
    bg = [newColor retain];
}

- (NSColor *)getBackground
{
    return bg;
}

- (void)dealloc
{
    [slices release];
    [bg release];
    [super dealloc];
}

- (BOOL)acceptsMouseEvents
{
    return YES;
}

@end
