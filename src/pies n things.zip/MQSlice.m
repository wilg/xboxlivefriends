//
//  MQSlice.m
//  
//
//  Created by John Carlyle on 11/12/06.
//  Copyright 2006 mindquirk. All rights reserved.
//

#import "MQSlice.h"


@implementation MQSlice

- (id)init  
{
	return [self initWithColor:[NSColor blueColor] slice:180.0 message:@"Unknown Slice"];
}

- (id)initWithColor:(NSColor *)theColor slice:(float)theSlice message:(NSString *)theMessage
{
    self = [super init];
    if (self)   {
        color = [theColor retain];
        slice = theSlice;
        message = [theMessage retain];
    }
    return self;
}


- (void)setBezierPath:(NSBezierPath *)newPath
{
    [path release];
    path = [newPath retain];
}

- (NSBezierPath *)getBezierPath
{
    return path;
}


- (void)setColor:(NSColor *)newColor
{
    [color release];
    color = [newColor retain];
}

- (NSColor *)getColor
{
    return color;
}


- (void)setSlice:(float)newSlice
{
    slice = newSlice;
}

- (float)getSlice
{
    return slice;
}


- (void)setMessage:(NSString *)newMessage
{
    [message release];
    message = [newMessage retain];
}

- (NSString *)getMessage
{
    return message;
}

- (void)dealloc
{
    [message release];
    [color release];
    [super dealloc];
}

+ (MQSlice *)sliceWithColor:(NSColor *)theColor slice:(float)theSlice message:(NSString *)theMessage
{
	return [[MQSlice alloc] initWithColor:theColor slice:theSlice message:theMessage];
}

@end
