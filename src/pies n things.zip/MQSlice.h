

#import <Cocoa/Cocoa.h>


@interface MQSlice : NSObject {
    NSBezierPath *path;
    NSColor *color;
    float slice;
    NSString *message;
}

- (void)setBezierPath:(NSBezierPath *)newPath;
- (NSBezierPath *)getBezierPath;

- (void)setColor:(NSColor *)newColor;
- (NSColor *)getColor;

- (void)setSlice:(float)newSlice;
- (float)getSlice;

- (void)setMessage:(NSString *)newMessage;
- (NSString *)getMessage;


+ (MQSlice *)sliceWithColor:(NSColor *)theColor slice:(float)theSlice message:(NSString *)theMessage;
- (id)initWithColor:(NSColor *)theColor slice:(float)theSlice message:(NSString *)theMessage;

@end
